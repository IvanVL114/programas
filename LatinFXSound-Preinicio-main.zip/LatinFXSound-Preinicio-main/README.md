# LatinFXSound-Preinicio
Primer proyecto de trabajo formal (primer trabajo). Pagina web para adquisición de FX Sounds con suscripción.
